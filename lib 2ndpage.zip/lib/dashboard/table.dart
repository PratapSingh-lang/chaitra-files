import 'package:flutter/material.dart';

class Newtable extends StatefulWidget {
  const Newtable({super.key});

  @override
  State<Newtable> createState() => _NewtableState();
}

class _NewtableState extends State<Newtable> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Table(
          children: [
            TableRow(
              children: [
                Text('2'),
                Text('2'),
                Text('2'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

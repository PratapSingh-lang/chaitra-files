// ignore_for_file: file_names

import 'package:flutter/material.dart';
import 'package:new_dashboard/dashboard/table.dart';

import 'bannersec.dart';
import 'colors.dart';

class PlansSection extends StatelessWidget {
  const PlansSection({
    Key? key,
    required this.height,
    required this.width,
  }) : super(key: key);

  final double height;
  final double width;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
                height: 60,
                width: MediaQuery.of(context).size.width,
                margin: const EdgeInsets.symmetric(
                  vertical: 12,
                  horizontal: 20,
                ),
                padding: const EdgeInsets.all(10),
                decoration: const BoxDecoration(
                  color: Color.fromARGB(115, 49, 159, 13),
                  borderRadius: BorderRadius.all(
                    Radius.circular(8),
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text(
                      'Hello Super Admin 1',
                      style: TextStyle(
                          color: blackColor,
                          fontSize: 15,
                          fontWeight: FontWeight.w600),
                    ),
                    Text(
                      "Welcome message here",
                      style: TextStyle(
                          color: blackColor,
                          fontSize: 12,
                          fontWeight: FontWeight.w600),
                    )
                  ],
                )),
            Container(
              child: BannerSection(height: height, width: width),
            ),
            Container(
              //  margin: const EdgeInsets.all(15.0),

              decoration:
                  BoxDecoration(border: Border.all(color: Colors.black)),

              width: MediaQuery.of(context).size.width,
              margin: const EdgeInsets.symmetric(
                vertical: 20,
                horizontal: 18,
              ),
              padding: const EdgeInsets.all(10),
              child: Table(
                border: TableBorder.symmetric(),
                children: [
                  TableRow(
                    children: [
                      Text('Organization Name'),
                      Text('Signotory Name'),
                      Text('Mobile'),
                      Text('Email Address'),
                      Text('Status'),
                      Text('Actions'),
                    ],
                  ),
                  TableRow(
                    children: [
                      Text('Organizatin 1'),
                      Text('User 1'),
                      Text('9999999999'),
                      Text('user@domin.com'),
                      Text('Pending'),
                      Text('2'),
                    ],
                  ),
                  TableRow(
                    children: [
                      Text('Organizatin 1'),
                      Text('User 1'),
                      Text('9999999999'),
                      Text('user@domin.com'),
                      Text('Pending'),
                      Text('2'),
                    ],
                  ),
                  TableRow(
                    children: [
                      Text('Organizatin 1'),
                      Text('User 1'),
                      Text('9999999999'),
                      Text('user@domin.com'),
                      Text('Pending'),
                      Text('2'),
                    ],
                  ),
                  TableRow(
                    children: [
                      Text('Organizatin 1'),
                      Text('User 1'),
                      Text('9999999999'),
                      Text('user@domin.com'),
                      Text('Pending'),
                      Text('2'),
                    ],
                  ),
                  TableRow(
                    children: [
                      Text('Organizatin 1'),
                      Text('User 1'),
                      Text('9999999999'),
                      Text('user@domin.com'),
                      Text('Pending'),
                      Text('2'),
                    ],
                  ),
                  TableRow(
                    children: [
                      Text('Organizatin 1'),
                      Text('User 1'),
                      Text('9999999999'),
                      Text('user@domin.com'),
                      Text('Pending'),
                      Text('2'),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

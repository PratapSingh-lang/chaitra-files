import 'package:flutter/material.dart';

const secondaryColor = Color.fromARGB(255, 84, 0, 167);
const backgroundColor = Color(0XFFE5E5E5);
const primaryColor = Color.fromARGB(255, 7, 108, 171);
const blackColor = Color.fromARGB(255, 3, 6, 8);

const webBarColor = Color.fromARGB(1, 26, 3, 110);
const barSelectedColor = Color.fromARGB(255, 247, 116, 1);
const plnttlcontCol =
    Color.fromARGB(255, 55, 2, 105); //plans title container colour
const aboutesigncolor = Color.fromARGB(255, 55, 2, 105);
const obATextcolor =
    Color.fromARGB(255, 26, 3, 110); //ON Boarding ASP text color
const appTutBgcolor =
    Color.fromARGB(255, 26, 3, 110); //Application Tutorial Section color
const footerBgcolor = Color.fromARGB(255, 26, 3, 110); //F
const contuctusTextcolor =
    Color.fromARGB(255, 26, 3, 110); //Contact Us Text Section color
const contuctusContTextcolor =
    Color.fromARGB(255, 55, 2, 105); //Contact Us Container Section color
const contuctUsContBordTextcolor =
    Color.fromARGB(255, 26, 3, 110); //Contact Us Container border Section color
const contuctUsButtoncolor = Color.fromARGB(
    255, 7, 204, 151); //Contact Us Container border Section color

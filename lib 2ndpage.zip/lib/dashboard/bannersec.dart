// ignore_for_file: file_names

import 'package:flutter/material.dart';
import 'package:new_dashboard/dashboard/table.dart';

import '../reusable.dart/reusable.dart';

class BannerSection extends StatelessWidget {
  const BannerSection({
    Key? key,
    required this.height,
    required this.width,
  }) : super(key: key);

  final double height;
  final double width;

  @override
  Widget build(BuildContext context) {
    final double contHeight = height * 0.3;
    final double contWidth = width * 0.2;

    return Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Spacer(),
            ReusableFeaturesContainer(
              width: contWidth,
              height: contHeight,
              title: "ASP",
              descrip1: "Total Registerd Users",
              descrip2: "Total Registerd Users This Month",
              descrip3: "Total pending registration Request",
            ),
            const Spacer(),
            ReusableFeaturesContainer(
              width: contWidth,
              height: contHeight,
              title: "ESP",
              descrip1: "Total Registerd Users",
              descrip2: "Total Registerd Users This Month",
              descrip3: "Total pending registration Request",
            ),
            const Spacer(),
            ReusableFeaturesContainer(
              width: contWidth,
              height: contHeight,
              title: "eKYC",
              descrip1: "Total Registerd Users",
              descrip2: "Total Registerd Users This Month",
              descrip3: "Total pending registration Request",
            ),
          ]),
          SizedBox(
            height: 10,
          ),
          Column(children: [
            Container(
              child: Text("Recent Activities"),
            ),
            // Container(
            //   child: NewTable(),
            // )
          ])
        ]);
  }
}

import 'package:flutter/material.dart';

class Datafile extends StatefulWidget {
  const Datafile({super.key});

  @override
  State<Datafile> createState() => _DatafileState();
}

class _DatafileState extends State<Datafile> {
  final bool _customTileExpanded = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: const <Widget>[
        ExpansionTile(
          leading: Icon(Icons.dashboard),
          title: Text(
            'DASHBOARD',
          ),
        ),
        ExpansionTile(
          leading: Icon(Icons.dashboard),
          title: Text('Web Portal'),
        ),
        ExpansionTile(
          leading: Icon(Icons.dashboard),
          title: Text('ASP'),
          children: <Widget>[
            ListTile(title: Text('eKYC Verification')),
            ListTile(title: Text('ASP Reports')),
            ListTile(title: Text('ASP Audits')),
          ],
        ),
        ExpansionTile(
          leading: Icon(Icons.dashboard),
          title: Text('ESP'),
          children: <Widget>[
            ListTile(title: Text('ESP Partner Management')),
            ListTile(title: Text('ESP Bills')),
            ListTile(title: Text('ESP Transaction')),
            ListTile(title: Text('ESP Reports')),
            ListTile(title: Text('ESP Audits')),
          ],
        ),
        ExpansionTile(
          leading: Icon(Icons.dashboard),
          title: Text(
            'eKYC',
          ),
          children: <Widget>[
            ListTile(title: Text('eKYC Reports')),
            ListTile(title: Text('eKYC Audits')),
          ],
        ),
        ExpansionTile(
          leading: Icon(Icons.dashboard),
          title: Text(
            'CA',
          ),
          children: <Widget>[
            ListTile(title: Text('CA Reports')),
            ListTile(title: Text('CA Audits')),
          ],
        ),
        ExpansionTile(
          leading: Icon(Icons.dashboard),
          title: Text(
            'User Management',
          ),
          children: <Widget>[
            ListTile(title: Text('Users')),
            ListTile(title: Text('Groups')),
            ListTile(title: Text('Roles')),
          ],
        ),
      ],
    );
  }
}

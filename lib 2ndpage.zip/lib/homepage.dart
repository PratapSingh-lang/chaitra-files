import 'package:flutter/material.dart';

import 'Desktop.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 88, 97, 145),
        title: const Text(
          'BEL Admin',
          style: TextStyle(fontStyle: FontStyle.italic),
        ),
        actions: const <Widget>[
          Text(
            'Super Admin 1',
            style: TextStyle(fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          Icon(
            Icons.account_circle,
            color: Colors.white,
          ),
        ],
      ),
      body: const Desktop(),
    );
  }
}

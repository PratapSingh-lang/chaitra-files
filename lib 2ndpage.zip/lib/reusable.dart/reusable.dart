import 'package:flutter/material.dart';

import '../dashboard/colors.dart';

class ReusableFeaturesContainer extends StatelessWidget {
  const ReusableFeaturesContainer({
    Key? key,
    required this.width,
    required this.height,
    required this.title,
    required this.descrip1,
    required this.descrip2,
    required this.descrip3,
    // required CrossAxisAlignment crossAxisAlignment,
    // required MainAxisAlignment mainAxisAlignment,
  }) : super(key: key);

  final double width;
  final double height;
  final String title;
  final String descrip1;
  final String descrip2;
  final String descrip3;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      width: width,
      margin: EdgeInsets.only(left: width * 0.01, right: width * 0.01),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          const Spacer(),
          Text(
            title,
            style: const TextStyle(
              color: aboutesigncolor,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          Text(
            descrip1,
            textAlign: TextAlign.left,
            style: const TextStyle(
              color: aboutesigncolor,
              fontSize: 14,
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          Text(
            descrip2,
            textAlign: TextAlign.left,
            style: const TextStyle(
              color: aboutesigncolor,
              fontSize: 14,
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          Text(
            descrip3,
            textAlign: TextAlign.left,
            style: const TextStyle(
              color: aboutesigncolor,
              fontSize: 14,
            ),
          ),
          const SizedBox(
            height: 20,
          ),
        ],
      ),
    );
  }
}

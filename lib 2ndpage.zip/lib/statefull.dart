import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(),
        body: const Datafile(),
      ),
    );
  }
}

class Datafile extends StatefulWidget {
  const Datafile({super.key});

  @override
  State<Datafile> createState() => _DatafileState();
}

class _DatafileState extends State<Datafile> {
  bool _customTileExpanded = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: const <Widget>[
        ExpansionTile(
          leading: Icon(Icons.dashboard),
          title: Text('ExpansionTile 1'),
          children: <Widget>[
            ListTile(title: Text('This is tile number 1')),
          ],
        ),
        ExpansionTile(
          leading: Icon(Icons.dashboard),
          title: Text('ExpansionTile 1'),
          children: <Widget>[
            ListTile(title: Text('This is tile number 1')),
            ListTile(title: Text('This is tile number 1')),
          ],
        ),
        ExpansionTile(
          leading: Icon(Icons.dashboard),
          title: Text('ExpansionTile 1'),
          children: <Widget>[
            ListTile(title: Text('This is tile number 1')),
          ],
        ),
      ],
    );
  }
}

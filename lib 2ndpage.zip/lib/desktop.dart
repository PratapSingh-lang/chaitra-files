import 'package:flutter/material.dart';

import 'dashboard/plans.dart';
import 'datafile.dart';

class Desktop extends StatefulWidget {
  const Desktop({super.key});

  @override
  State<Desktop> createState() => _DesktopState();
}

class _DesktopState extends State<Desktop> {
  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 76, 114, 170),
      body: SizedBox(
        child: Row(
          children: <Widget>[
            const Expanded(
              flex: 3, // 20%
              child: Datafile(),
            ),
            Expanded(
              flex: 12, // 60%
              child: PlansSection(
                height: height,
                width: width,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
